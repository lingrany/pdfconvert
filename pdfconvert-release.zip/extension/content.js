// 内容脚本 - 在网页中运行
class ContentScript {
    constructor() {
        this.init();
    }

    init() {
        // 监听来自popup和background的消息
        chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
            this.handleMessage(message, sender, sendResponse);
            return true; // 保持消息通道开启
        });

        // 添加快捷键支持
        document.addEventListener('keydown', (event) => {
            this.handleKeydown(event);
        });

        // 页面加载完成后检查是否需要显示转换提示
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', () => {
                this.checkPageContent();
            });
        } else {
            this.checkPageContent();
        }
    }

    handleMessage(message, sender, sendResponse) {
        switch (message.action) {
            case 'extractContent':
                sendResponse(this.extractPageContent());
                break;
            case 'convertToPDF':
                this.convertToPDF().then(result => {
                    sendResponse(result);
                }).catch(error => {
                    sendResponse({ success: false, error: error.message });
                });
                break;
            case 'getPageStats':
                sendResponse(this.getPageStats());
                break;
            case 'highlightContent':
                this.highlightContent(message.selector);
                sendResponse({ success: true });
                break;
            default:
                sendResponse({ success: false, error: 'Unknown action' });
        }
    }

    handleKeydown(event) {
        // Ctrl+Shift+P 快速转换
        if (event.ctrlKey && event.shiftKey && event.key === 'P') {
            event.preventDefault();
            this.quickConvert();
        }
        // Ctrl+Shift+S 显示页面统计
        else if (event.ctrlKey && event.shiftKey && event.key === 'S') {
            event.preventDefault();
            this.showPageStats();
        }
    }

    extractPageContent() {
        return {
            content: document.documentElement.outerHTML,
            title: document.title,
            url: window.location.href,
            text: document.body.innerText,
            wordCount: document.body.innerText.split(/\s+/).length,
            images: Array.from(document.images).map(img => ({
                src: img.src,
                alt: img.alt,
                width: img.naturalWidth,
                height: img.naturalHeight
            })),
            links: Array.from(document.links).map(link => ({
                href: link.href,
                text: link.textContent.trim()
            })),
            headings: Array.from(document.querySelectorAll('h1, h2, h3, h4, h5, h6')).map(h => ({
                level: h.tagName.toLowerCase(),
                text: h.textContent.trim()
            }))
        };
    }

    getPageStats() {
        const text = document.body.innerText;
        const images = document.images.length;
        const links = document.links.length;
        const words = text.split(/\s+/).filter(word => word.length > 0).length;
        const chars = text.length;
        const headings = document.querySelectorAll('h1, h2, h3, h4, h5, h6').length;

        return {
            words: words,
            characters: chars,
            images: images,
            links: links,
            headings: headings,
            estimatedReadTime: Math.ceil(words / 200) // 假设每分钟200词
        };
    }

    async convertToPDF() {
        try {
            // 显示转换提示
            this.showConvertingNotification();

            const pageContent = this.extractPageContent();
            
            // 发送到后台脚本处理
            const response = await chrome.runtime.sendMessage({
                action: 'convertPage',
                data: pageContent
            });

            if (response.success) {
                this.showSuccessNotification();
                return { success: true };
            } else {
                throw new Error(response.error);
            }
        } catch (error) {
            this.showErrorNotification(error.message);
            return { success: false, error: error.message };
        }
    }

    quickConvert() {
        // 快捷键触发的快速转换
        this.convertToPDF();
    }

    showPageStats() {
        const stats = this.getPageStats();
        const message = `页面统计信息：
• 字数: ${stats.words.toLocaleString()}
• 字符数: ${stats.characters.toLocaleString()}
• 图片数: ${stats.images}
• 链接数: ${stats.links}
• 标题数: ${stats.headings}
• 预估阅读时间: ${stats.estimatedReadTime} 分钟

快捷键：
• Ctrl+Shift+P: 快速转换为PDF
• Ctrl+Shift+S: 显示页面统计`;

        this.showNotification(message, 'info', 8000);
    }

    checkPageContent() {
        // 检查页面是否适合转换为PDF
        const stats = this.getPageStats();
        
        // 如果页面内容很多，可以显示转换建议
        if (stats.words > 1000 && !this.hasShownSuggestion) {
            this.hasShownSuggestion = true;
            setTimeout(() => {
                this.showConversionSuggestion(stats);
            }, 3000);
        }
    }

    showConversionSuggestion(stats) {
        const suggestion = document.createElement('div');
        suggestion.id = 'pdf-converter-suggestion';
        suggestion.innerHTML = `
            <div style="
                position: fixed;
                top: 20px;
                right: 20px;
                background: linear-gradient(135deg, #007bff, #0056b3);
                color: white;
                padding: 16px 20px;
                border-radius: 8px;
                font-family: Arial, sans-serif;
                font-size: 14px;
                z-index: 9999;
                box-shadow: 0 8px 25px rgba(0,0,0,0.15);
                max-width: 320px;
                cursor: pointer;
                transition: transform 0.2s;
            " onmouseover="this.style.transform='translateY(-2px)'" onmouseout="this.style.transform='translateY(0)'">
                <div style="display: flex; align-items: center; margin-bottom: 8px;">
                    <span style="font-size: 18px; margin-right: 8px;">📄</span>
                    <strong>PDF转换器</strong>
                </div>
                <div style="margin-bottom: 8px; opacity: 0.9;">
                    检测到长篇内容 (${stats.words.toLocaleString()} 字)
                </div>
                <div style="font-size: 12px; opacity: 0.8;">
                    点击转换为PDF，或按 Ctrl+Shift+P
                </div>
                <div style="position: absolute; top: 8px; right: 8px; cursor: pointer; opacity: 0.7;" onclick="this.parentElement.parentElement.remove()">✕</div>
            </div>
        `;
        
        suggestion.addEventListener('click', (e) => {
            if (e.target.textContent !== '✕') {
                this.quickConvert();
                suggestion.remove();
            }
        });
        
        document.body.appendChild(suggestion);
        
        // 10秒后自动移除
        setTimeout(() => {
            if (suggestion.parentNode) {
                suggestion.remove();
            }
        }, 10000);
    }

    highlightContent(selector) {
        // 高亮显示指定内容
        const elements = document.querySelectorAll(selector);
        elements.forEach(el => {
            el.style.backgroundColor = '#fff3cd';
            el.style.border = '2px solid #ffc107';
            el.style.borderRadius = '4px';
            el.style.padding = '4px';
        });

        // 3秒后移除高亮
        setTimeout(() => {
            elements.forEach(el => {
                el.style.backgroundColor = '';
                el.style.border = '';
                el.style.borderRadius = '';
                el.style.padding = '';
            });
        }, 3000);
    }

    showConvertingNotification() {
        this.removeExistingNotifications();
        
        const notification = document.createElement('div');
        notification.id = 'pdf-converter-notification';
        notification.innerHTML = `
            <div style="
                position: fixed;
                top: 20px;
                right: 20px;
                background: #007bff;
                color: white;
                padding: 12px 20px;
                border-radius: 6px;
                font-family: Arial, sans-serif;
                font-size: 14px;
                z-index: 9999;
                box-shadow: 0 4px 12px rgba(0,0,0,0.15);
                display: flex;
                align-items: center;
            ">
                <div style="
                    width: 16px;
                    height: 16px;
                    border: 2px solid rgba(255,255,255,0.3);
                    border-top: 2px solid white;
                    border-radius: 50%;
                    animation: spin 1s linear infinite;
                    margin-right: 8px;
                "></div>
                正在转换为PDF...
            </div>
            <style>
                @keyframes spin {
                    0% { transform: rotate(0deg); }
                    100% { transform: rotate(360deg); }
                }
            </style>
        `;
        
        document.body.appendChild(notification);
    }

    showSuccessNotification() {
        this.removeExistingNotifications();
        this.showNotification('✅ PDF转换完成！', 'success', 3000);
    }

    showErrorNotification(message) {
        this.removeExistingNotifications();
        this.showNotification(`❌ 转换失败: ${message}`, 'error', 5000);
    }

    showNotification(message, type = 'info', duration = 3000) {
        this.removeExistingNotifications();
        
        const notification = document.createElement('div');
        notification.id = 'pdf-converter-notification';
        
        const colors = {
            success: { bg: '#d4edda', color: '#155724', border: '#c3e6cb' },
            error: { bg: '#f8d7da', color: '#721c24', border: '#f5c6cb' },
            info: { bg: '#e3f2fd', color: '#1976d2', border: '#bbdefb' }
        };
        
        const colorScheme = colors[type] || colors.info;
        
        notification.innerHTML = `
            <div style="
                position: fixed;
                top: 20px;
                right: 20px;
                background: ${colorScheme.bg};
                color: ${colorScheme.color};
                border: 1px solid ${colorScheme.border};
                padding: 12px 20px;
                border-radius: 6px;
                font-family: Arial, sans-serif;
                font-size: 14px;
                z-index: 9999;
                box-shadow: 0 4px 12px rgba(0,0,0,0.15);
                max-width: 350px;
                white-space: pre-line;
                line-height: 1.4;
            ">
                ${message}
            </div>
        `;
        
        document.body.appendChild(notification);
        
        // 自动移除
        setTimeout(() => {
            this.removeExistingNotifications();
        }, duration);
    }

    removeExistingNotifications() {
        const existing = document.getElementById('pdf-converter-notification');
        if (existing) {
            existing.remove();
        }
        
        const suggestion = document.getElementById('pdf-converter-suggestion');
        if (suggestion) {
            suggestion.remove();
        }
    }
}

// 初始化内容脚本
if (typeof window !== 'undefined' && window.chrome && chrome.runtime) {
    new ContentScript();
}