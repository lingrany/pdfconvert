// 后台脚本 - Service Worker
class BackgroundService {
    constructor() {
        this.serverUrl = 'http://localhost:3000';
        this.init();
    }

    init() {
        // 安装时的初始化
        chrome.runtime.onInstalled.addListener(() => {
            console.log('PDF转换器插件已安装');
            this.createContextMenus();
        });

        // 处理右键菜单点击
        chrome.contextMenus.onClicked.addListener((info, tab) => {
            this.handleContextMenuClick(info, tab);
        });

        // 处理来自content script的消息
        chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
            this.handleMessage(message, sender, sendResponse);
            return true; // 保持消息通道开启
        });

        // 处理快捷键
        chrome.commands.onCommand.addListener((command) => {
            this.handleCommand(command);
        });
    }

    createContextMenus() {
        // 移除现有菜单
        chrome.contextMenus.removeAll(() => {
            // 创建右键菜单
            chrome.contextMenus.create({
                id: 'convertToPDF',
                title: '转换为PDF',
                contexts: ['page', 'selection']
            });
            
            chrome.contextMenus.create({
                id: 'convertLinkToPDF',
                title: '转换链接为PDF',
                contexts: ['link']
            });

            chrome.contextMenus.create({
                id: 'separator1',
                type: 'separator',
                contexts: ['page', 'link']
            });

            chrome.contextMenus.create({
                id: 'openBatchConverter',
                title: '打开批量转换器',
                contexts: ['page']
            });
        });
    }

    async handleContextMenuClick(info, tab) {
        try {
            switch (info.menuItemId) {
                case 'convertToPDF':
                    await this.convertCurrentPage(tab);
                    break;
                case 'convertLinkToPDF':
                    await this.convertLinkPage(info.linkUrl, tab);
                    break;
                case 'openBatchConverter':
                    chrome.tabs.create({ url: this.serverUrl });
                    break;
            }
        } catch (error) {
            console.error('右键菜单操作失败:', error);
            this.showNotification('操作失败', `${error.message}`, 'basic');
        }
    }

    async handleMessage(message, sender, sendResponse) {
        try {
            switch (message.action) {
                case 'convertPage':
                    const result = await this.convertCurrentPage(sender.tab);
                    sendResponse({ success: true, result });
                    break;
                case 'getPageContent':
                    const content = await this.getPageContent(sender.tab.id);
                    sendResponse({ success: true, content });
                    break;
                default:
                    sendResponse({ success: false, error: 'Unknown action' });
            }
        } catch (error) {
            console.error('消息处理失败:', error);
            sendResponse({ success: false, error: error.message });
        }
    }

    async handleCommand(command) {
        try {
            if (command === 'convert-page') {
                const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
                await this.convertCurrentPage(tab);
            }
        } catch (error) {
            console.error('快捷键处理失败:', error);
        }
    }

    // 转换当前页面
    async convertCurrentPage(tab) {
        try {
            this.showNotification('PDF转换器', '正在转换为PDF...', 'basic');

            // 检查标签页是否有效
            if (!tab || !tab.id) {
                throw new Error('无法获取当前标签页信息');
            }

            // 直接传递URL让服务器去抓取 - 单页面模式
            const response = await fetch(`${this.serverUrl}/api/convert-page`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    url: tab.url,
                    title: tab.title,
                    mode: 'single-page' // 标记为单页面模式
                })
            });

            if (!response.ok) {
                const errorData = await response.json().catch(() => ({ error: response.statusText }));
                throw new Error(errorData.error || `HTTP ${response.status}: ${response.statusText}`);
            }

            // 下载PDF
            const blob = await response.blob();
            const url = URL.createObjectURL(blob);
            
            await chrome.downloads.download({
                url: url,
                filename: `${this.sanitizeFilename(tab.title)}.pdf`,
                saveAs: false
            });

            this.showNotification('PDF转换器', 'PDF转换完成！', 'basic');

            // 保存到历史记录
            await this.saveToHistory(tab.url, tab.title);

        } catch (error) {
            console.error('转换失败:', error);
            this.showNotification('PDF转换器', `转换失败: ${error.message}`, 'basic');
            throw error;
        }
    }

    // 转换链接页面
    async convertLinkPage(linkUrl, tab) {
        try {
            this.showNotification('PDF转换器', '正在转换链接页面...', 'basic');

            // 直接发送URL到服务器进行抓取和转换
            const response = await fetch(`${this.serverUrl}/api/crawl`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    url: linkUrl,
                    maxDepth: 1,
                    maxPages: 1
                })
            });

            if (!response.ok) {
                const errorData = await response.json().catch(() => ({ error: response.statusText }));
                throw new Error(errorData.error || `HTTP ${response.status}: ${response.statusText}`);
            }

            const result = await response.json();
            
            // 下载生成的PDF
            const downloadUrl = `${this.serverUrl}/api/download/${result.pdfPath}`;
            
            await chrome.downloads.download({
                url: downloadUrl,
                filename: result.pdfPath,
                saveAs: false
            });

            this.showNotification('PDF转换器', '链接转换完成！', 'basic');

        } catch (error) {
            console.error('链接转换失败:', error);
            this.showNotification('PDF转换器', `链接转换失败: ${error.message}`, 'basic');
            throw error;
        }
    }

    // 显示通知
    showNotification(title, message, type = 'basic') {
        const options = {
            type: type,
            iconUrl: 'icons/icon48.png',
            title: title,
            message: message
        };

        chrome.notifications.create(options);
    }

    // 文件名清理函数
    sanitizeFilename(filename) {
        if (!filename) return 'untitled';
        return filename.replace(/[<>:"/\\|?*]/g, '_').substring(0, 100);
    }

    // 保存到历史记录
    async saveToHistory(url, title) {
        try {
            const historyItem = {
                url: url,
                title: title,
                timestamp: Date.now()
            };

            const { history = [] } = await chrome.storage.local.get(['history']);
            history.unshift(historyItem);
            
            // 只保留最近50条记录
            const limitedHistory = history.slice(0, 50);
            
            await chrome.storage.local.set({ history: limitedHistory });
        } catch (error) {
            console.error('保存历史记录失败:', error);
        }
    }

}

// 初始化后台服务
new BackgroundService();