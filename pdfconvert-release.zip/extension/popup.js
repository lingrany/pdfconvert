class PopupController {
    constructor() {
        this.serverUrl = 'http://localhost:3000';
        this.init();
    }

    async init() {
        await this.loadPageInfo();
        this.bindEvents();
        this.loadSettings();
    }

    async loadPageInfo() {
        try {
            const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
            
            document.getElementById('pageTitle').textContent = tab.title || '无标题';
            document.getElementById('pageUrl').textContent = tab.url || '';
            
            // 存储当前标签信息
            this.currentTab = tab;
        } catch (error) {
            console.error('加载页面信息失败:', error);
            document.getElementById('pageTitle').textContent = '无法获取页面信息';
        }
    }

    bindEvents() {
        // 转换当前页面
        document.getElementById('convertCurrent').addEventListener('click', () => {
            this.convertCurrentPage();
        });

        // 批量转换
        document.getElementById('openBatch').addEventListener('click', () => {
            chrome.tabs.create({
                url: `${this.serverUrl}`
            });
        });

        // 设置
        document.getElementById('openSettings').addEventListener('click', () => {
            this.openSettings();
        });

        // 历史记录
        document.getElementById('viewHistory').addEventListener('click', () => {
            this.viewHistory();
        });
    }

    async convertCurrentPage() {
        if (!this.currentTab) {
            this.showError('无法获取当前页面信息');
            return;
        }

        try {
            // 获取转换模式
            const isSinglePage = document.getElementById('singlePage').checked;
            
            if (isSinglePage) {
                await this.convertSinglePage();
            } else {
                await this.convertMultiPage();
            }

        } catch (error) {
            console.error('转换失败:', error);
            this.showError(`转换失败: ${error.message}`);
        }
    }

    async convertSinglePage() {
        this.showStatus('正在获取页面内容...');
        
        console.log('开始单页面转换');
        console.log('当前标签页信息:', this.currentTab);

        // 检查标签页是否有效
        if (!this.currentTab || !this.currentTab.id) {
            throw new Error('无法获取当前标签页信息');
        }

        this.showStatus('正在生成PDF...');

        // 获取选项
        const options = {
            includeImages: document.getElementById('includeImages').checked,
            includeStyles: document.getElementById('includeStyles').checked
        };

        console.log('转换选项:', options);

        // 直接传递URL让服务器去抓取单个页面
        const response = await fetch(`${this.serverUrl}/api/convert-page`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                url: this.currentTab.url,
                title: this.currentTab.title,
                options: options,
                mode: 'single-page' // 标记为单页面模式
            })
        });

        console.log('服务器响应状态:', response.status, response.statusText);

        if (!response.ok) {
            const errorData = await response.json().catch(() => ({ error: response.statusText }));
            console.error('服务器返回错误:', errorData);
            throw new Error(`单页面转换失败: ${errorData.error || response.statusText}`);
        }

        // 下载PDF
        const blob = await response.blob();
        const url = URL.createObjectURL(blob);
        
        console.log('开始下载PDF, 文件大小:', blob.size);
        
        await chrome.downloads.download({
            url: url,
            filename: `${this.sanitizeFilename(this.currentTab.title)}.pdf`
        });

        this.showSuccess('单页面PDF转换完成！');
        
        // 保存到历史记录
        this.saveToHistory(this.currentTab.url, `${this.currentTab.title} (单页面)`);
    }

    async convertMultiPage() {
        this.showStatus('正在启动多页面抓取...');
        
        console.log('开始多页面转换，将抓取相关链接');
        
        // 获取选项
        const options = {
            url: this.currentTab.url,
            maxDepth: 2,  // 默认抓取2层
            maxPages: 50, // 默认最多50页
            delay: 1000,
            includeImages: document.getElementById('includeImages').checked,
            includeStyles: document.getElementById('includeStyles').checked
        };

        console.log('多页面抓取配置:', options);

        // 发送到服务器进行多页面抓取
        const response = await fetch(`${this.serverUrl}/api/crawl`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(options)
        });

        if (!response.ok) {
            const errorData = await response.json().catch(() => ({ error: response.statusText }));
            throw new Error(`多页面抓取失败: ${errorData.error || response.statusText}`);
        }

        const result = await response.json();
        
        console.log('多页面抓取结果:', result);
        
        this.showStatus('正在下载PDF...');
        
        // 下载生成的PDF
        const downloadUrl = `${this.serverUrl}/api/download/${result.pdfPath}`;
        
        await chrome.downloads.download({
            url: downloadUrl,
            filename: result.pdfPath
        });

        this.showSuccess(`多页面PDF转换完成！共${result.totalPages}页`);
        
        // 保存到历史记录
        this.saveToHistory(this.currentTab.url, `${this.currentTab.title} (多页面, ${result.totalPages}页)`);
    }

    showStatus(message) {
        const statusElement = document.getElementById('status');
        const statusText = document.getElementById('statusText');
        
        statusText.textContent = message;
        statusElement.classList.remove('hidden');
        
        // 禁用按钮
        document.getElementById('convertCurrent').disabled = true;
    }

    showSuccess(message) {
        this.hideStatus();
        // 显示成功提示
        this.showNotification(message, 'success');
    }

    showError(message) {
        this.hideStatus();
        this.showNotification(message, 'error');
    }

    showNotification(message, type) {
        // 移除现有通知
        const existing = document.querySelector('.notification');
        if (existing) {
            existing.remove();
        }

        // 创建通知元素
        const notification = document.createElement('div');
        notification.className = `notification ${type}`;
        notification.textContent = message;
        
        // 添加样式
        notification.style.cssText = `
            position: fixed;
            top: 10px;
            left: 50%;
            transform: translateX(-50%);
            padding: 10px 16px;
            border-radius: 4px;
            font-size: 14px;
            z-index: 10000;
            max-width: 300px;
            text-align: center;
            ${type === 'success' ? 'background: #d4edda; color: #155724; border: 1px solid #c3e6cb;' : 'background: #f8d7da; color: #721c24; border: 1px solid #f5c6cb;'}
        `;
        
        document.body.appendChild(notification);
        
        // 3秒后自动移除
        setTimeout(() => {
            if (notification.parentNode) {
                notification.remove();
            }
        }, 3000);
    }

    hideStatus() {
        document.getElementById('status').classList.add('hidden');
        document.getElementById('convertCurrent').disabled = false;
    }

    sanitizeFilename(filename) {
        return filename.replace(/[<>:"/\\|?*]/g, '_').substring(0, 100);
    }

    loadSettings() {
        chrome.storage.sync.get(['includeImages', 'includeStyles'], (result) => {
            document.getElementById('includeImages').checked = result.includeImages !== false;
            document.getElementById('includeStyles').checked = result.includeStyles !== false;
        });
    }

    async saveToHistory(url, title) {
        try {
            const historyItem = {
                url: url,
                title: title,
                timestamp: Date.now()
            };

            const { history = [] } = await chrome.storage.local.get(['history']);
            history.unshift(historyItem);
            
            // 只保留最近50条记录
            const limitedHistory = history.slice(0, 50);
            
            await chrome.storage.local.set({ history: limitedHistory });
        } catch (error) {
            console.error('保存历史记录失败:', error);
        }
    }

    openSettings() {
        // 简单的设置功能
        const currentImages = document.getElementById('includeImages').checked;
        const currentStyles = document.getElementById('includeStyles').checked;
        
        const includeImages = confirm(`是否包含图片？\n当前设置: ${currentImages ? '是' : '否'}`);
        const includeStyles = confirm(`是否保留样式？\n当前设置: ${currentStyles ? '是' : '否'}`);
        
        document.getElementById('includeImages').checked = includeImages;
        document.getElementById('includeStyles').checked = includeStyles;
        
        // 保存设置
        chrome.storage.sync.set({
            includeImages: includeImages,
            includeStyles: includeStyles
        });
    }

    async viewHistory() {
        try {
            const { history = [] } = await chrome.storage.local.get(['history']);
            
            if (history.length === 0) {
                alert('暂无转换历史记录');
                return;
            }
            
            const historyText = history.slice(0, 10).map((item, index) => {
                const date = new Date(item.timestamp).toLocaleString();
                return `${index + 1}. ${item.title}\n   ${item.url}\n   时间: ${date}`;
            }).join('\n\n');
            
            alert(`最近10条转换记录:\n\n${historyText}`);
        } catch (error) {
            console.error('获取历史记录失败:', error);
            alert('获取历史记录失败');
        }
    }
}

// 初始化
document.addEventListener('DOMContentLoaded', () => {
    new PopupController();
});