const cheerio = require('cheerio');

class GitBookOptimizer {
    constructor(options = {}) {
        this.options = {
            removeNavigation: true,
            removeAds: true,
            removeComments: true,
            optimizeImages: true,
            ...options
        };
        
        // GitBook特定选择器配置
        this.selectors = {
            // 内容区域选择器（按优先级排序）
            content: [
                '[data-testid="page-content"]',
                '.page-inner',
                '.markdown-section',
                '.book-body .page-inner',
                'main .markdown-section',
                '.content'
            ],
            
            // 标题选择器
            title: [
                '[data-testid="page-title"]',
                '.page-title',
                '.markdown-section h1:first-child',
                'h1:first-child',
                'title'
            ],
            
            // 导航链接选择器
            navigation: [
                '.summary a[href]',
                '.book-summary a[href]',
                '[data-testid="sidebar"] a[href]',
                '.sidebar a[href]',
                'nav a[href]',
                '.gitbook-link'
            ],
            
            // 需要移除的元素
            remove: [
                '.gitbook-link',
                '.page-footer',
                '.navigation',
                '.ads',
                '.advertisement',
                '[data-ad]',
                '.cookie-notice',
                '.feedback',
                '.edit-page',
                '.github-link',
                '.powered-by',
                '.book-summary-toggle',
                '.toolbar',
                '.page-actions',
                // 搜索相关元素
                '.search-results',
                '.search-box',
                '.search-input',
                '.search-form',
                '[class*="search"]',
                '[id*="search"]',
                // GitBook特定的搜索和导航元素
                '.book-search',
                '.book-search-results',
                '.gitbook-search',
                '.no-results',
                '[class*="no-results"]',
                '[class*="results-matching"]',
                // 页面底部元素
                '.page-navigation',
                '.prev-next',
                '.book-navigation',
                '[class*="navigation"]',
                // 其他可能包含"No results"的元素
                '.empty-state',
                '.placeholder',
                '[class*="empty"]',
                '[class*="placeholder"]'
            ],
            
            // 需要保留的元素
            keep: [
                'code',
                'pre',
                'blockquote',
                'table',
                'img',
                'h1', 'h2', 'h3', 'h4', 'h5', 'h6',
                'p', 'ul', 'ol', 'li',
                'a[href^="http"]' // 外部链接
            ]
        };
        
        // GitBook网站识别模式
        this.gitbookPatterns = [
            /gitbook\.io/,
            /\.gitbook\.com/,
            /github\.io.*gitbook/,
            /gitbook/i
        ];
        
        // GitBook HTML特征
        this.gitbookFeatures = [
            'gitbook',
            'data-testid',
            'book-summary',
            'markdown-section',
            'page-inner'
        ];
    }

    // 检测是否为GitBook网站
    isGitBookSite(url, html) {
        // URL模式检测
        const urlMatch = this.gitbookPatterns.some(pattern => pattern.test(url));
        if (urlMatch) return true;
        
        // HTML特征检测
        const $ = cheerio.load(html);
        
        // 检查特定的CSS类和属性
        const hasGitBookClasses = this.gitbookFeatures.some(feature => {
            return $(`.${feature}`).length > 0 || $(`[class*="${feature}"]`).length > 0;
        });
        
        // 检查meta标签
        const generator = $('meta[name="generator"]').attr('content') || '';
        const hasGitBookMeta = generator.toLowerCase().includes('gitbook');
        
        // 检查特定的data属性
        const hasDataTestId = $('[data-testid]').length > 0;
        
        return hasGitBookClasses || hasGitBookMeta || hasDataTestId;
    }

    // 优化GitBook页面内容提取
    extractOptimizedContent($, url) {
        // 首先移除不需要的元素
        this.removeUnwantedElements($);
        
        // 提取主要内容
        const content = this.extractMainContent($, url);
        
        // 提取标题
        const title = this.extractTitle($);
        
        // 优化链接
        this.optimizeLinks($, url);
        
        return {
            title: title || '无标题',
            content: content || '无内容',
            isOptimized: true
        };
    }

    // 移除不需要的元素
    removeUnwantedElements($) {
        // 首先移除所有指定的选择器元素
        this.selectors.remove.forEach(selector => {
            try {
                $(selector).remove();
            } catch (error) {
                console.warn(`移除元素失败 ${selector}:`, error.message);
            }
        });
        
        // 移除包含特定文本的元素
        const unwantedTexts = [
            'No results matching',
            'results matching',
            'No results found',
            '没有找到结果',
            '搜索结果',
            'Search results',
            'Powered by GitBook',
            'Edit on GitHub',
            '编辑此页',
            'Last updated'
        ];
        
        // 逐个检查所有元素的文本内容
        $('*').each(function() {
            const $element = $(this);
            const elementText = $element.text().trim();
            
            // 如果元素的文本内容匹配不需要的文本，则移除
            if (unwantedTexts.some(unwanted => elementText.toLowerCase().includes(unwanted.toLowerCase()))) {
                // 检查是否为单独的元素（不包含其他有用内容）
                const hasOtherContent = $element.children().length > 0 && 
                    $element.children().text().trim() !== elementText;
                
                if (!hasOtherContent && elementText.length < 200) {
                    console.log(`移除包含不需要文本的元素: "${elementText.substring(0, 50)}..."`);
                    $element.remove();
                }
            }
        });
        
        // 移除空的div元素
        $('div, section, aside').each(function() {
            const $div = $(this);
            if ($div.children().length === 0 && $div.text().trim() === '') {
                $div.remove();
            }
        });
        
        // 移除脚本和样式
        $('script, style, noscript, iframe').remove();
        
        // 移除注释
        if (this.options.removeComments) {
            this.removeComments($);
        }
        
        // 最后再次清理可能剩余的空元素
        $('*').each(function() {
            const $element = $(this);
            const textContent = $element.text().trim();
            
            // 如果元素只包含空白或无意义的文本，则移除
            if (textContent === '' || 
                textContent === 'No results matching ""' ||
                textContent.match(/^\s*results matching\s*["']?\s*["']?\s*$/i) ||
                textContent.match(/^\s*No results\s*$/i)) {
                $element.remove();
            }
        });
    }

    // 提取主要内容
    extractMainContent($, url = '') {
        let content = '';
        
        // 检测并过滤错误页面和空状态页面
        if (this.isErrorOrEmptyPage($, url)) {
            console.log('检测到错误页面或空状态页面，跳过内容提取');
            return '';
        }
        
        // 按优先级尝试不同的内容选择器
        for (const selector of this.selectors.content) {
            const element = $(selector).first();
            if (element.length && element.html()) {
                content = element.html();
                console.log(`使用选择器提取内容: ${selector}`);
                break;
            }
        }
        
        // 如果没有找到特定内容区域，使用备用方案
        if (!content.trim()) {
            // 移除导航和侧边栏后提取body内容
            $('nav, .nav, .navigation, .sidebar, .menu, header, footer').remove();
            content = $('main').html() || $('body').html() || '';
            console.log('使用备用方案提取内容');
        }
        
        // 再次检查内容是否为错误状态
        const cleanedContent = this.cleanContent(content, $);
        if (this.isContentEmpty(cleanedContent)) {
            console.log('提取的内容为空或无效');
            return '';
        }
        
        return cleanedContent;
    }

    // 提取标题
    extractTitle($) {
        let title = '';
        
        // 按优先级尝试不同的标题选择器
        for (const selector of this.selectors.title) {
            const element = $(selector).first();
            if (element.length && element.text().trim()) {
                title = element.text().trim();
                break;
            }
        }
        
        // 清理标题
        return this.cleanTitle(title);
    }

    // 清理内容
    cleanContent(content, $) {
        if (!content) return '';
        
        const $content = cheerio.load(content);
        
        // 先清理包含"No results matching"的元素
        $content('*').each(function() {
            const $element = $content(this);
            const text = $element.text().trim();
            
            // 检查是否包含不需要的文本
            const unwantedPatterns = [
                /No results matching/i,
                /results matching\s*["']?\s*["']?/i,
                /^\s*No results\s*$/i,
                /Search results/i,
                /Powered by GitBook/i,
                /Edit on GitHub/i,
                /Last updated/i
            ];
            
            if (unwantedPatterns.some(pattern => pattern.test(text))) {
                // 检查是否为单独的不需要内容
                if (text.length < 200 && !$element.find('h1, h2, h3, h4, h5, h6, p, ul, ol, table').length) {
                    $element.remove();
                    return;
                }
            }
        });
        
        // 清理属性，保留重要的
        $content('*').each(function() {
            const element = $content(this);
            const tagName = element.get(0).tagName.toLowerCase();
            
            // 需要保留的属性
            const keepAttrs = {
                'a': ['href', 'title'],
                'img': ['src', 'alt', 'title', 'width', 'height'],
                'code': ['class'],
                'pre': ['class'],
                'table': ['class'],
                'th': ['colspan', 'rowspan'],
                'td': ['colspan', 'rowspan']
            };
            
            const allowedAttrs = keepAttrs[tagName] || [];
            const currentAttrs = Object.keys(element.attr() || {});
            
            currentAttrs.forEach(attr => {
                if (!allowedAttrs.includes(attr)) {
                    element.removeAttr(attr);
                }
            });
        });
        
        // 最后清理HTML内容，移除剩余的不需要文本
        let finalHtml = $content.html();
        
        // 使用正则表达式清理文本
        const cleanupPatterns = [
            // 直接匹配文本
            /No results matching\s*["']?[^"']*["']?/gi,
            /results matching\s*["']?[^"']*["']?/gi,
            /^\s*No results\s*$/gmi,
            // 匹配包含HTML标签的内容
            /<[^>]*>\s*No results matching[^<]*<\/[^>]*>/gi,
            /<[^>]*>\s*results matching[^<]*<\/[^>]*>/gi,
            // 匹配更多可能的变体
            /No\s+results\s+matching\s*["']?[^"']*["']?/gi,
            /results\s+matching\s*["']?[^"']*["']?/gi,
            // 删除空的段落和元素
            /<p>\s*<\/p>/gi,
            /<div>\s*<\/div>/gi,
            /<span>\s*<\/span>/gi,
            // 删除只包含空白的元素
            /<[^>]+>\s*<\/[^>]+>/gi
        ];
        
        cleanupPatterns.forEach(pattern => {
            finalHtml = finalHtml.replace(pattern, '');
        });
        
        // 最终的文本清理 - 移除剩余的不需要文本
        finalHtml = this.finalTextCleanup(finalHtml);
        
        return finalHtml;
    }
    
    // 最终文本清理方法
    finalTextCleanup(html) {
        if (!html) return '';
        
        const $final = cheerio.load(html);
        
        // 逐个检查所有文本节点
        $final('*').contents().each(function() {
            if (this.type === 'text') {
                const text = this.data.trim();
                
                // 检查是否包含不需要的文本
                const unwantedTextPatterns = [
                    /No results matching/i,
                    /results matching/i,
                    /No results found/i,
                    /Search results/i,
                    /Powered by GitBook/i
                ];
                
                if (unwantedTextPatterns.some(pattern => pattern.test(text))) {
                    // 直接删除这个文本节点
                    $final(this).remove();
                }
            }
        });
        
        // 清理空元素
        $final('*').each(function() {
            const $element = $final(this);
            const text = $element.text().trim();
            
            // 如果元素只包含空白或不需要的文本，则删除
            if (text === '' || 
                text === 'No results matching ""' ||
                text.match(/^\s*results matching\s*["']?\s*["']?\s*$/i) ||
                text.match(/^\s*No results\s*$/i) ||
                text.match(/^\s*No results matching\s*$/i)) {
                $element.remove();
            }
        });
        
        return $final.html() || '';
    }

    // 清理标题
    cleanTitle(title) {
        if (!title) return '';
        
        return title
            .replace(/^\d+\.\s*/, '') // 移除章节编号
            .replace(/^[·•\-\s]*/, '') // 移除前缀符号
            .replace(/[·•\-\s]*$/, '') // 移除后缀符号
            .replace(/\s+/g, ' ') // 规范化空格
            .trim();
    }

    // 优化链接
    optimizeLinks($, baseUrl) {
        $('a[href]').each((i, element) => {
            const $link = $(element);
            const href = $link.attr('href');
            
            if (!href) return;
            
            try {
                // 转换相对链接为绝对链接
                if (!href.startsWith('http') && !href.startsWith('#')) {
                    const absoluteUrl = new URL(href, baseUrl).href;
                    $link.attr('href', absoluteUrl);
                }
                
                // 为外部链接添加标识
                if (href.startsWith('http') && !href.includes(new URL(baseUrl).hostname)) {
                    $link.attr('target', '_blank');
                    $link.attr('rel', 'noopener noreferrer');
                }
            } catch (error) {
                console.warn(`处理链接失败 ${href}:`, error.message);
            }
        });
    }

    // 移除HTML注释
    removeComments($) {
        $('*').contents().each(function() {
            if (this.type === 'comment') {
                $(this).remove();
            }
        });
    }

    // 发现GitBook导航链接
    findNavigationLinks($, baseUrl) {
        const links = [];
        const foundUrls = new Set();
        
        // 按优先级尝试不同的导航选择器
        for (const selector of this.selectors.navigation) {
            $(selector).each((i, element) => {
                try {
                    const $link = $(element);
                    const href = $link.attr('href');
                    
                    if (!href || href.startsWith('#') || href.startsWith('javascript:')) {
                        return;
                    }
                    
                    // 构建完整URL
                    let fullUrl;
                    try {
                        fullUrl = new URL(href, baseUrl).href;
                    } catch (error) {
                        return;
                    }
                    
                    // 避免重复
                    if (foundUrls.has(fullUrl)) {
                        return;
                    }
                    
                    foundUrls.add(fullUrl);
                    
                    const title = $link.text().trim() || 
                                 $link.attr('title') || 
                                 $link.attr('data-title') || '';
                    
                    links.push({
                        url: fullUrl,
                        title: this.cleanTitle(title),
                        selector: selector,
                        isNavigation: true
                    });
                    
                } catch (error) {
                    console.warn('处理导航链接时出错:', error.message);
                }
            });
            
            // 如果已经找到链接，优先使用第一个选择器的结果
            if (links.length > 0) {
                break;
            }
        }
        
        console.log(`GitBook导航发现 ${links.length} 个链接`);
        return links;
    }

    // 检查链接是否应该包含在抓取中
    shouldIncludeLink(url, baseUrl, options = {}) {
        try {
            const urlObj = new URL(url);
            const baseUrlObj = new URL(baseUrl);
            
            // 只抓取同一域名
            if (urlObj.hostname !== baseUrlObj.hostname) {
                return false;
            }
            
            // GitBook特定的URL过滤
            const excludePatterns = [
                /\/edit\//,           // 编辑页面
                /\/admin\//,          // 管理页面
                /\/api\//,            // API接口
                /\/login/,            // 登录页面
                /\/register/,         // 注册页面
                /\/settings/,         // 设置页面
                /\/download/,         // 下载页面
                /\/print/,            // 打印页面
                /\.(pdf|epub|mobi)$/, // 电子书文件
                /\.(zip|tar|gz)$/,    // 压缩文件
                /\/search\?/,         // 搜索结果页
                /#/,                  // 锚点链接（如果路径相同）
                /\/search/,           // 搜索页面
                /\?q=/,               // 查询参数
                /\?search=/,          // 搜索参数
            ];
            
            if (excludePatterns.some(pattern => pattern.test(url))) {
                return false;
            }
            
            return true;
            
        } catch (error) {
            return false;
        }
    }

    // 检测是否为错误页面或空状态页面
    isErrorOrEmptyPage($, url = '') {
        const errorIndicators = [
            'No results matching',
            'No results found',
            '没有找到结果',
            '无搜索结果',
            '404 Not Found',
            'Page not found',
            '页面不存在',
            'Access Denied',
            '访问被拒绝',
            'Error 404',
            'Error 403',
            'Error 500',
            'Search results',
            'No content available',
            '暂无内容'
        ];
        
        const pageText = $('body').text().toLowerCase();
        const pageTitle = $('title').text().toLowerCase();
        
        // 检查页面文本是否包含错误指示器
        const hasErrorText = errorIndicators.some(indicator => 
            pageText.includes(indicator.toLowerCase()) || 
            pageTitle.includes(indicator.toLowerCase())
        );
        
        // 检查页面是否主要是搜索表单
        const hasSearchForm = $('form[role="search"], form[class*="search"], input[type="search"]').length > 0;
        const hasMinimalContent = pageText.trim().length < 100;
        
        // 检查是否是搜索结果页面
        const isSearchPage = /search|query|q=/.test(url || '') || 
                            $('[class*="search-results"], [id*="search-results"]').length > 0;
        
        return hasErrorText || (hasSearchForm && hasMinimalContent) || isSearchPage;
    }

    // 检查内容是否为空或无效
    isContentEmpty(content) {
        if (!content || typeof content !== 'string') {
            return true;
        }
        
        // 创建临时jQuery对象来分析内容
        const $temp = cheerio.load(content);
        
        // 移除空白和换行符后的纯文本
        const textContent = $temp.text().replace(/\s+/g, ' ').trim();
        
        // 如果文本内容太短，认为是空内容
        if (textContent.length < 20) {
            return true;
        }
        
        // 检查是否主要是错误消息（只有在内容很短时才认为是错误）
        if (textContent.length < 100) {
            const errorKeywords = [
                'no results matching',
                'no results found',
                'page not found',
                'error 404',
                'access denied',
                'results matching'
            ];
            
            const lowerText = textContent.toLowerCase();
            const hasErrorKeywords = errorKeywords.some(keyword => lowerText.includes(keyword));
            
            return hasErrorKeywords;
        }
        
        // 对于较长的内容，检查是否主要由错误消息组成
        const errorPortion = this.calculateErrorContentPortion(textContent);
        return errorPortion > 0.8; // 如果80%以上都是错误内容，则认为空
    }
    
    // 计算错误内容的比例
    calculateErrorContentPortion(text) {
        const errorKeywords = [
            'no results matching',
            'no results found',
            'results matching',
            'search results',
            'powered by gitbook'
        ];
        
        const lowerText = text.toLowerCase();
        let errorLength = 0;
        
        errorKeywords.forEach(keyword => {
            const regex = new RegExp(keyword.replace(/\s+/g, '\\s*'), 'gi');
            const matches = lowerText.match(regex);
            if (matches) {
                errorLength += matches.length * keyword.length;
            }
        });
        
        return errorLength / text.length;
    }

    // 获取GitBook网站的最优配置
    getOptimalConfig(url) {
        const config = {
            maxDepth: 4,           // 增加抓取深度
            maxPages: 500,         // 大幅增加最大页面数
            delay: 1000,
            includeImages: true,
            includeStyles: true,
            waitForSelector: '.markdown-section, [data-testid="page-content"]',
            excludeSelectors: this.selectors.remove,
            contentSelectors: this.selectors.content
        };
        
        // 根据URL特征调整配置
        if (url.includes('github.io')) {
            config.delay = 500; // GitHub Pages通常响应较快
            config.maxPages = 800; // 可以抓取更多页面
        }
        
        if (url.includes('gitbook.io')) {
            config.delay = 1500; // GitBook.io 可能需要更长的加载时间
            config.waitForSelector = '[data-testid="page-content"]';
            config.maxPages = 600;
        }
        
        return config;
    }
}

module.exports = GitBookOptimizer;