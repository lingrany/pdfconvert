const puppeteer = require('puppeteer');
const cheerio = require('cheerio');
const { URL } = require('url');
const fs = require('fs-extra');
const path = require('path');
const GitBookOptimizer = require('./gitbookOptimizer');

class WebsiteCrawler {
    constructor(options = {}) {
        this.maxDepth = options.maxDepth || 3;
        this.maxPages = options.maxPages || 500;  // 从50增加到500
        this.delay = options.delay || 1000;
        this.includeImages = options.includeImages !== false;
        this.includeStyles = options.includeStyles !== false;
        this.onProgress = options.onProgress || (() => {});
        
        this.visitedUrls = new Set();
        this.toVisit = [];
        this.pages = [];
        this.browser = null;
        this.baseUrl = null;
        this.baseDomain = null;
        
        // 初始化GitBook优化器
        this.gitbookOptimizer = new GitBookOptimizer();
        this.isGitbookSite = false;
        this.gitbookConfig = null;
    }

    async crawl(startUrl) {
        try {
            console.log(`开始抓取网站: ${startUrl}`);
            
            // 初始化浏览器
            this.browser = await puppeteer.launch({
                headless: 'new',
                args: [
                    '--no-sandbox',
                    '--disable-setuid-sandbox',
                    '--disable-dev-shm-usage',
                    '--disable-accelerated-2d-canvas',
                    '--no-first-run',
                    '--no-zygote',
                    '--disable-gpu'
                ]
            });

            // 设置基础URL
            this.baseUrl = new URL(startUrl);
            this.baseDomain = this.baseUrl.hostname;
            
            // 检测并优化GitBook网站
            await this.detectAndOptimizeGitBook(startUrl);
            
            // 初始化抓取队列
            this.toVisit.push({
                url: startUrl,
                depth: 0,
                title: '首页'
            });

            this.onProgress({
                stage: 'initializing',
                message: this.isGitbookSite ? '正在初始化GitBook爬虫...' : '正在初始化爬虫...',
                totalPages: 0,
                completedPages: 0,
                currentUrl: startUrl
            });

            // 开始递归抓取
            await this.crawlRecursive();

            return this.pages;

        } catch (error) {
            console.error('抓取过程中发生错误:', error);
            throw error;
        } finally {
            if (this.browser) {
                await this.browser.close();
            }
        }
    }

    async crawlRecursive() {
        const maxConcurrent = 3; // 最大并发数
        let activePromises = [];

        while (this.toVisit.length > 0 && this.pages.length < this.maxPages) {
            // 控制并发数
            while (activePromises.length < maxConcurrent && this.toVisit.length > 0) {
                const pageInfo = this.toVisit.shift();
                
                if (this.visitedUrls.has(pageInfo.url)) {
                    continue;
                }

                this.visitedUrls.add(pageInfo.url);
                
                const promise = this.crawlPage(pageInfo)
                    .then(() => {
                        // 从活动Promise列表中移除
                        const index = activePromises.indexOf(promise);
                        if (index > -1) {
                            activePromises.splice(index, 1);
                        }
                    })
                    .catch(error => {
                        console.error(`抓取页面失败 ${pageInfo.url}:`, error.message);
                        // 从活动Promise列表中移除
                        const index = activePromises.indexOf(promise);
                        if (index > -1) {
                            activePromises.splice(index, 1);
                        }
                    });

                activePromises.push(promise);
            }

            // 等待至少一个Promise完成
            if (activePromises.length > 0) {
                await Promise.race(activePromises);
            }

            // 更新进度
            this.onProgress({
                stage: 'crawling',
                message: `正在抓取页面... (${this.pages.length}/${this.maxPages})`,
                totalPages: Math.min(this.visitedUrls.size + this.toVisit.length, this.maxPages),
                completedPages: this.pages.length,
                currentUrl: this.pages.length > 0 ? this.pages[this.pages.length - 1].url : '',
                foundUrls: this.visitedUrls.size
            });
        }

        // 等待所有剩余的Promise完成
        await Promise.all(activePromises);
    }

    async crawlPage(pageInfo) {
        const { url, depth, title } = pageInfo;
        
        try {
            console.log(`正在抓取页面: ${url} (深度: ${depth})`);

            const page = await this.browser.newPage();
            
            // 设置页面选项
            await page.setViewport({ width: 1200, height: 800 });
            await page.setUserAgent('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36');

            // 设置拦截器以优化加载速度
            await page.setRequestInterception(true);
            page.on('request', (req) => {
                const resourceType = req.resourceType();
                if (resourceType === 'image' && !this.includeImages) {
                    req.abort();
                } else if (resourceType === 'stylesheet' && !this.includeStyles) {
                    req.abort();
                } else if (['font', 'media'].includes(resourceType)) {
                    req.abort();
                } else {
                    req.continue();
                }
            });

            // 加载页面
            await page.goto(url, {
                waitUntil: 'networkidle0',
                timeout: 30000
            });

            // GitBook特定的等待策略
            if (this.isGitbookSite && this.gitbookConfig.waitForSelector) {
                try {
                    await page.waitForSelector(this.gitbookConfig.waitForSelector, { timeout: 10000 });
                } catch (error) {
                    console.warn(`等待GitBook选择器失败: ${error.message}`);
                }
            }

            // 等待页面内容加载
            await page.waitForTimeout(this.delay);

            // 获取页面内容
            const content = await page.content();
            const $ = cheerio.load(content);

            // 提取页面信息
            const pageData = await this.extractPageData($, url, page);

            // 如果页面数据为null，跳过此页面
            if (pageData === null) {
                console.log(`跳过页面: ${url}`);
                await page.close();
                return; // 直接返回，不添加到结果集
            }

            // 最终内容验证和清理
            pageData.content = this.finalContentValidation(pageData.content, pageData.title, url);
            
            // 再次检查清理后的内容是否仍然有效
            if (!pageData.content || pageData.content.trim().length < 50) {
                console.log(`清理后内容太少，跳过页面: ${url}`);
                await page.close();
                return;
            }

            // 添加到结果集
            this.pages.push(pageData);

            // 如果还没达到最大深度且不是单页面模式，继续发现链接
            if (depth < this.maxDepth && this.maxPages > 1) {
                const links = await this.findLinks($, url, depth + 1);
                this.toVisit.push(...links);
            } else if (this.maxPages === 1) {
                console.log('单页面模式，不发现新链接');
            }

            await page.close();
            
            // 添加延迟避免过快请求
            if (this.delay > 0) {
                await new Promise(resolve => setTimeout(resolve, this.delay));
            }

        } catch (error) {
            console.error(`抓取页面失败 ${url}:`, error.message);
            throw error;
        }
    }

    async extractPageData($, url, page) {
        let title, content;
        
        if (this.isGitbookSite) {
            // 使用GitBook优化器提取内容
            const optimizedData = this.gitbookOptimizer.extractOptimizedContent($, url);
            title = optimizedData.title;
            content = optimizedData.content;
        } else {
            title = this.extractGenericTitle($);
            content = this.extractGenericContent($);
            // 清理内容
            content = this.cleanContent(content);
        }

        // 检查内容是否为空或无效
        if (!content || content.trim() === '') {
            console.log(`页面内容为空，跳过: ${url}`);
            return null; // 返回null表示跳过此页面
        }

        // 检查是否为错误页面（通用检查）
        if (this.isErrorPage(title, content)) {
            console.log(`检测到错误页面，跳过: ${url}`);
            return null;
        }

        // 截取页面截图（可选）
        let screenshot = null;
        if (this.includeImages) {
            try {
                screenshot = await page.screenshot({
                    fullPage: true,
                    type: 'png'
                });
            } catch (error) {
                console.warn(`截图失败 ${url}:`, error.message);
            }
        }

        return {
            url,
            title: title || '无标题',
            content: content || '无内容',
            screenshot,
            timestamp: new Date().toISOString(),
            isGitbook: this.isGitbookSite
        };
    }

    // 检测并配置GitBook网站
    async detectAndOptimizeGitBook(url) {
        try {
            // 先访问首页检测网站类型
            const page = await this.browser.newPage();
            await page.goto(url, { waitUntil: 'networkidle0', timeout: 30000 });
            const html = await page.content();
            await page.close();
            
            // 使用GitBook优化器检测
            this.isGitbookSite = this.gitbookOptimizer.isGitBookSite(url, html);
            
            if (this.isGitbookSite) {
                console.log('检测到GitBook网站，启用优化配置');
                
                // 获取优化配置
                this.gitbookConfig = this.gitbookOptimizer.getOptimalConfig(url);
                
                // 应用优化配置
                this.delay = this.gitbookConfig.delay;
                
                console.log('GitBook优化配置已应用:', {
                    delay: this.gitbookConfig.delay,
                    waitForSelector: this.gitbookConfig.waitForSelector
                });
            }
            
        } catch (error) {
            console.warn('GitBook检测失败，使用通用模式:', error.message);
            this.isGitbookSite = false;
        }
    }

    // 这些方法已被GitBook优化器替代，保留用于向后兼容
    extractGitbookTitle($) {
        return this.gitbookOptimizer.extractTitle($);
    }

    extractGitbookContent($) {
        return this.gitbookOptimizer.extractMainContent($);
    }

    extractGenericTitle($) {
        return $('h1').first().text().trim() || 
               $('title').text().trim() || 
               '无标题';
    }

    extractGenericContent($) {
        // 移除不需要的元素
        $('nav, header, footer, script, style, .ads, .sidebar').remove();
        
        // 尝试找到主要内容区域
        let content = $('main').html() || 
                     $('.content').html() || 
                     $('#content').html() || 
                     $('article').html() || 
                     $('body').html() || '';

        return content;
    }

    cleanContent(content) {
        if (!content) return '';

        const $ = cheerio.load(content);
        
        // 移除脚本和样式
        $('script, style, noscript').remove();
        
        // 移除空元素
        $('*').each(function() {
            if ($(this).is(':empty') && !$(this).is('img, br, hr, input')) {
                $(this).remove();
            }
        });

        // 清理属性
        $('*').each(function() {
            const element = $(this);
            // 保留重要属性
            const keepAttrs = ['href', 'src', 'alt', 'title'];
            const attrs = Object.keys(element.attr() || {});
            
            attrs.forEach(attr => {
                if (!keepAttrs.includes(attr)) {
                    element.removeAttr(attr);
                }
            });
        });

        return $.html();
    }

    // 最终内容验证和清理
    finalContentValidation(content, title, url) {
        if (!content || typeof content !== 'string') {
            return '';
        }

        // 使用正则表达式移除不需要的文本
        let cleanedContent = content;
        
        // 定义所有可能的不需要文本模式
        const unwantedPatterns = [
            /No results matching\s*["']?[^"'<>]*["']?/gi,
            /results matching\s*["']?[^"'<>]*["']?/gi,
            /No results found/gi,
            /Search results/gi,
            /Powered by GitBook/gi,
            /Edit on GitHub/gi,
            /Last updated/gi,
            /<[^>]*>\s*No results matching[^<]*<\/[^>]*>/gi,
            /<[^>]*>\s*results matching[^<]*<\/[^>]*>/gi,
            /^\s*No results matching\s*["']?[^"']*["']?\s*$/gm,
            /^\s*results matching\s*["']?[^"']*["']?\s*$/gm,
            /^\s*No results\s*$/gm
        ];
        
        // 逐个应用清理模式
        unwantedPatterns.forEach(pattern => {
            cleanedContent = cleanedContent.replace(pattern, '');
        });
        
        // 使用cheerio进行更精确的清理
        try {
            const $ = cheerio.load(cleanedContent);
            
            // 移除包含不需要关键词的元素
            $('*').each(function() {
                const $element = $(this);
                const text = $element.text().trim();
                
                const unwantedKeywords = [
                    'No results matching',
                    'results matching',
                    'No results found',
                    'Search results',
                    'Powered by GitBook'
                ];
                
                if (unwantedKeywords.some(keyword => 
                    text.toLowerCase().includes(keyword.toLowerCase()) && text.length < 100
                )) {
                    if (!$element.find('h1, h2, h3, h4, h5, h6, p, ul, ol, table, img').length || 
                        $element.children().length === 0) {
                        $element.remove();
                    }
                }
            });
            
            cleanedContent = $.html();
        } catch (error) {
            console.warn(`内容清理时出错 ${url}:`, error.message);
        }
        
        // 最后一次文本清理
        cleanedContent = cleanedContent
            .replace(/\s*No results matching[^\n]*/gi, '')
            .replace(/\s*results matching[^\n]*/gi, '')
            .replace(/\s*No results found[^\n]*/gi, '')
            .replace(/\n\s*\n\s*\n/g, '\n\n')
            .trim();
        
        return cleanedContent;
    }

    async findLinks($, baseUrl, depth) {
        const links = [];
        const baseUrlObj = new URL(baseUrl);
        const foundUrls = new Set();

        if (this.isGitbookSite) {
            // 使用GitBook优化器发现导航链接
            const gitbookLinks = this.gitbookOptimizer.findNavigationLinks($, baseUrl);
            
            gitbookLinks.forEach(linkData => {
                if (!foundUrls.has(linkData.url) && 
                    !this.visitedUrls.has(linkData.url) &&
                    this.gitbookOptimizer.shouldIncludeLink(linkData.url, baseUrl)) {
                    
                    foundUrls.add(linkData.url);
                    links.push({
                        url: linkData.url,
                        depth,
                        title: linkData.title
                    });
                }
            });
        } else {
            // 通用链接发现
            const linkSelectors = ['a[href]'];
            
            linkSelectors.forEach(selector => {
                $(selector).each((i, element) => {
                    try {
                        const href = $(element).attr('href');
                        if (!href) return;

                        // 构建完整URL
                        let fullUrl;
                        try {
                            fullUrl = new URL(href, baseUrl).href;
                        } catch (error) {
                            return; // 跳过无效URL
                        }

                        // 过滤条件
                        if (!this.shouldIncludeUrl(fullUrl, baseUrlObj)) {
                            return;
                        }

                        // 避免重复
                        if (foundUrls.has(fullUrl) || this.visitedUrls.has(fullUrl)) {
                            return;
                        }

                        foundUrls.add(fullUrl);

                        const title = $(element).text().trim() || $(element).attr('title') || '';
                        
                        links.push({
                            url: fullUrl,
                            depth,
                            title
                        });

                    } catch (error) {
                        console.warn('处理链接时出错:', error.message);
                    }
                });
            });
        }

        console.log(`在 ${baseUrl} 发现 ${links.length} 个新链接`);
        return links;
    }

    // 检查是否为错误页面（通用检查）
    isErrorPage(title, content) {
        const errorIndicators = [
            'No results matching',
            'No results found',
            '没有找到结果',
            '无搜索结果',
            '404 Not Found',
            'Page not found',
            '页面不存在',
            'Access Denied',
            '访问被拒绝',
            'Error 404',
            'Error 403',
            'Error 500',
            'Search results',
            'No content available',
            '暂无内容'
        ];
        
        const titleLower = (title || '').toLowerCase();
        const contentText = content ? cheerio.load(content).text().toLowerCase() : '';
        
        // 检查标题和内容是否包含错误指示器
        const hasErrorInTitle = errorIndicators.some(indicator => 
            titleLower.includes(indicator.toLowerCase())
        );
        
        const hasErrorInContent = errorIndicators.some(indicator => 
            contentText.includes(indicator.toLowerCase())
        );
        
        // 检查内容是否过短（可能是空页面）
        const isContentTooShort = contentText.trim().length < 50;
        
        return hasErrorInTitle || hasErrorInContent || isContentTooShort;
    }

    shouldIncludeUrl(url, baseUrlObj) {
        try {
            const urlObj = new URL(url);
            
            // 只抓取同一域名
            if (urlObj.hostname !== this.baseDomain) {
                return false;
            }

            // 排除特定文件类型
            const excludeExtensions = ['.jpg', '.jpeg', '.png', '.gif', '.pdf', '.zip', '.mp4', '.mp3'];
            if (excludeExtensions.some(ext => urlObj.pathname.toLowerCase().endsWith(ext))) {
                return false;
            }

            // 排除特定路径
            const excludePaths = ['/admin', '/login', '/api/', '/_', '/.*\\.json', '/search', '/edit'];
            if (excludePaths.some(pattern => new RegExp(pattern).test(urlObj.pathname))) {
                return false;
            }

            // 排除搜索相关的URL参数
            const searchParams = ['q', 'query', 'search', 's', 'keyword', 'term'];
            const hasSearchParams = searchParams.some(param => urlObj.searchParams.has(param));
            if (hasSearchParams) {
                console.log(`跳过搜索页面: ${url}`);
                return false;
            }

            // 排除锚点链接
            if (urlObj.hash && urlObj.pathname === baseUrlObj.pathname) {
                return false;
            }

            // 排除包含搜索关键词的URL
            const searchKeywords = ['search', 'query', 'find', 'results'];
            const urlString = url.toLowerCase();
            if (searchKeywords.some(keyword => urlString.includes(keyword))) {
                console.log(`跳过可能的搜索页面: ${url}`);
                return false;
            }

            return true;

        } catch (error) {
            return false;
        }
    }
}

module.exports = WebsiteCrawler;