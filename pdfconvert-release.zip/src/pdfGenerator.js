const puppeteer = require('puppeteer');
const fs = require('fs-extra');
const path = require('path');
const moment = require('moment');

class PDFGenerator {
    constructor(options = {}) {
        this.onProgress = options.onProgress || (() => {});
        this.outputDir = options.outputDir || path.join(process.cwd(), 'output');
        this.tempDir = path.join(this.outputDir, 'temp');
        
        // 处理图片和样式选项
        this.includeImages = options.includeImages !== false; // 默认包含图片
        this.includeStyles = options.includeStyles !== false; // 默认包含样式
        
        console.log('PDF生成器配置:', {
            includeImages: this.includeImages,
            includeStyles: this.includeStyles,
            outputDir: this.outputDir
        });
        
        // 确保目录存在
        fs.ensureDirSync(this.outputDir);
        fs.ensureDirSync(this.tempDir);
    }

    async generatePDF(pages, originalUrl) {
        try {
            console.log(`开始生成PDF，共 ${pages.length} 个页面`);
            
            this.onProgress({
                stage: 'pdf_generation',
                message: '正在准备PDF生成...',
                totalPages: pages.length,
                completedPages: 0
            });

            // 创建合并的HTML文档
            const mergedHtml = await this.createMergedHTML(pages, originalUrl);
            
            // 生成PDF
            const pdfPath = await this.generatePDFFromHTML(mergedHtml, originalUrl);
            
            // 清理临时文件
            await this.cleanup();
            
            console.log(`PDF生成完成: ${pdfPath}`);
            return pdfPath;

        } catch (error) {
            console.error('PDF生成失败:', error);
            await this.cleanup();
            throw error;
        }
    }

    async createMergedHTML(pages, originalUrl) {
        this.onProgress({
            stage: 'html_generation',
            message: '正在生成合并的HTML文档...',
            totalPages: pages.length,
            completedPages: 0
        });

        const urlObj = new URL(originalUrl);
        const siteName = urlObj.hostname;
        const timestamp = moment().format('YYYY-MM-DD HH:mm:ss');

        let mergedContent = `
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${siteName} - 完整站点内容</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Microsoft YaHei', 'PingFang SC', 'Helvetica Neue', Arial, sans-serif;
            line-height: 1.6;
            color: #333;
            background: #fff;
            font-size: 14px;
        }
        
        .cover-page {
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            text-align: center;
            page-break-after: always;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 40px;
        }
        
        .cover-title {
            font-size: 48px;
            font-weight: bold;
            margin-bottom: 20px;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
        }
        
        .cover-subtitle {
            font-size: 24px;
            margin-bottom: 40px;
            opacity: 0.9;
        }
        
        .cover-info {
            font-size: 18px;
            line-height: 2;
            background: rgba(255,255,255,0.1);
            padding: 30px;
            border-radius: 10px;
            backdrop-filter: blur(10px);
        }
        
        .toc {
            page-break-before: always;
            page-break-after: always;
            padding: 40px;
        }
        
        .toc-title {
            font-size: 36px;
            font-weight: bold;
            margin-bottom: 30px;
            color: #2c3e50;
            border-bottom: 3px solid #3498db;
            padding-bottom: 10px;
        }
        
        .toc-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 12px 0;
            border-bottom: 1px dotted #ddd;
            font-size: 16px;
        }
        
        .toc-item:hover {
            background-color: #f8f9fa;
        }
        
        .toc-title-text {
            flex: 1;
            margin-right: 20px;
        }
        
        .toc-page-number {
            color: #666;
            font-weight: bold;
        }
        
        .page-content {
            page-break-before: always;
            padding: 40px;
            min-height: 100vh;
        }
        
        .page-header {
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 2px solid #e9ecef;
        }
        
        .page-title {
            font-size: 32px;
            font-weight: bold;
            color: #2c3e50;
            margin-bottom: 10px;
        }
        
        .page-url {
            font-size: 14px;
            color: #6c757d;
            font-family: monospace;
            background: #f8f9fa;
            padding: 8px 12px;
            border-radius: 4px;
            word-break: break-all;
        }
        
        .page-body {
            font-size: 16px;
            line-height: 1.8;
        }
        
        .page-body h1, .page-body h2, .page-body h3, 
        .page-body h4, .page-body h5, .page-body h6 {
            margin-top: 30px;
            margin-bottom: 15px;
            color: #2c3e50;
        }
        
        .page-body h1 { font-size: 28px; }
        .page-body h2 { font-size: 24px; }
        .page-body h3 { font-size: 20px; }
        .page-body h4 { font-size: 18px; }
        .page-body h5 { font-size: 16px; }
        .page-body h6 { font-size: 14px; }
        
        .page-body p {
            margin-bottom: 15px;
            text-align: justify;
        }
        
        .page-body ul, .page-body ol {
            margin: 15px 0;
            padding-left: 30px;
        }
        
        .page-body li {
            margin-bottom: 8px;
        }
        
        .page-body blockquote {
            margin: 20px 0;
            padding: 15px 20px;
            background: #f8f9fa;
            border-left: 4px solid #3498db;
            font-style: italic;
        }
        
        .page-body pre {
            background: #f4f4f4;
            padding: 15px;
            border-radius: 5px;
            overflow-x: auto;
            margin: 15px 0;
            font-family: 'Courier New', monospace;
            font-size: 14px;
        }
        
        .page-body code {
            background: #f4f4f4;
            padding: 2px 6px;
            border-radius: 3px;
            font-family: 'Courier New', monospace;
            font-size: 14px;
        }
        
        .page-body img {
            max-width: 100%;
            height: auto;
            display: block;
            margin: 20px auto;
            border-radius: 5px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        
        .page-body table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
        }
        
        .page-body th, .page-body td {
            border: 1px solid #ddd;
            padding: 12px;
            text-align: left;
        }
        
        .page-body th {
            background: #f8f9fa;
            font-weight: bold;
        }
        
        .page-body a {
            color: #3498db;
            text-decoration: none;
        }
        
        .page-body a:hover {
            text-decoration: underline;
        }
        
        .footer {
            position: fixed;
            bottom: 30px;
            right: 30px;
            font-size: 12px;
            color: #666;
        }
        
        @media print {
            .footer {
                position: static;
                text-align: center;
                margin-top: 30px;
                border-top: 1px solid #eee;
                padding-top: 10px;
            }
        }
        
        .no-print {
            display: none;
        }
    </style>
</head>
<body>
    <!-- 封面页 -->
    <div class="cover-page">
        <div class="cover-title">网站内容合集</div>
        <div class="cover-subtitle">${siteName}</div>
        <div class="cover-info">
            <div><strong>原始网址:</strong> ${originalUrl}</div>
            <div><strong>生成时间:</strong> ${timestamp}</div>
            <div><strong>页面总数:</strong> ${pages.length} 页</div>
            <div><strong>生成工具:</strong> 网站多页面PDF转换工具</div>
        </div>
    </div>
    
    <!-- 目录页 -->
    <div class="toc">
        <h1 class="toc-title">目录</h1>
        ${pages.map((page, index) => `
            <div class="toc-item">
                <div class="toc-title-text">${this.escapeHtml(page.title)}</div>
                <div class="toc-page-number">${index + 1}</div>
            </div>
        `).join('')}
    </div>
`;

        // 添加每个页面的内容
        for (let i = 0; i < pages.length; i++) {
            const page = pages[i];
            
            this.onProgress({
                stage: 'html_generation',
                message: `正在处理页面: ${page.title}`,
                totalPages: pages.length,
                completedPages: i
            });

            // 最终清理页面内容
            let cleanedContent = this.finalContentCleanup(page.content || '');
            
            // 根据选项处理内容
            cleanedContent = this.processContentByOptions(cleanedContent);

            mergedContent += `
    <!-- 页面 ${i + 1}: ${this.escapeHtml(page.title)} -->
    <div class="page-content">
        <div class="page-header">
            <h1 class="page-title">${this.escapeHtml(page.title)}</h1>
            <div class="page-url">${this.escapeHtml(page.url)}</div>
        </div>
        <div class="page-body">
            ${cleanedContent || '<p>该页面没有内容</p>'}
        </div>
        <div class="footer">
            页面 ${i + 1} / ${pages.length} - 生成于 ${timestamp}
        </div>
    </div>
`;
        }

        mergedContent += `
</body>
</html>`;

        // 保存HTML文件
        const htmlPath = path.join(this.tempDir, 'merged.html');
        await fs.writeFile(htmlPath, mergedContent, 'utf8');
        
        console.log(`合并HTML文件已生成: ${htmlPath}`);
        return htmlPath;
    }

    async generatePDFFromHTML(htmlPath, originalUrl) {
        this.onProgress({
            stage: 'pdf_conversion',
            message: '正在转换为PDF...',
            totalPages: 1,
            completedPages: 0
        });

        const browser = await puppeteer.launch({
            headless: 'new',
            args: [
                '--no-sandbox',
                '--disable-setuid-sandbox',
                '--disable-dev-shm-usage',
                '--disable-web-security',
                '--allow-running-insecure-content'
            ]
        });

        try {
            const page = await browser.newPage();
            
            // 设置页面大小
            await page.setViewport({ width: 1200, height: 1600 });
            
            // 模拟浏览器打印时勾选"背景图片"选项的效果
            await page.emulateMediaType('print');
            
            // 强制启用背景图片渲染（模拟用户勾选"背景图片"选项）
            await page.evaluateOnNewDocument(() => {
                // 强制设置打印时显示背景
                Object.defineProperty(window, 'matchMedia', {
                    writable: true,
                    value: function(query) {
                        return {
                            matches: false,
                            media: query,
                            onchange: null,
                            addListener: function() {},
                            removeListener: function() {}
                        };
                    },
                });
                
                // 强制所有元素保留背景
                const style = document.createElement('style');
                style.textContent = `
                    * {
                        -webkit-print-color-adjust: exact !important;
                        color-adjust: exact !important;
                        print-color-adjust: exact !important;
                    }
                    @media print {
                        * {
                            -webkit-print-color-adjust: exact !important;
                            color-adjust: exact !important;
                            print-color-adjust: exact !important;
                        }
                    }
                `;
                document.head.appendChild(style);
            });
            
            // 加载HTML文件
            await page.goto(`file://${htmlPath}`, {
                waitUntil: 'networkidle0',
                timeout: 60000
            });

            // 等待页面完全加载
            await page.waitForTimeout(2000);

            // 生成PDF文件名
            const urlObj = new URL(originalUrl);
            const siteName = urlObj.hostname.replace(/[^a-zA-Z0-9]/g, '_');
            const timestamp = moment().format('YYYY-MM-DD_HH-mm-ss');
            const filename = `${siteName}_${timestamp}.pdf`;
            const pdfPath = path.join(this.outputDir, filename);

            // 生成PDF（模拟浏览器打印时勾选"背景图片"的效果）
            await page.pdf({
                path: pdfPath,
                format: 'A4',
                printBackground: true, // 确保背景样式被渲染
                margin: {
                    top: '20mm',
                    right: '20mm',
                    bottom: '20mm',
                    left: '20mm'
                },
                displayHeaderFooter: false,
                preferCSSPageSize: true,
                // 强化背景渲染设置（模拟浏览器"背景图片"选项）
                omitBackground: false, // 不忽略背景
                scale: 1, // 确保渲柕精度
                // 添加额外的背景支持参数
                tagged: false, // 禁用PDF的可访问性标签，减少渲染干扰
                outline: false, // 禁用大纲，专注内容渲染
            });

            this.onProgress({
                stage: 'pdf_conversion',
                message: 'PDF生成完成',
                totalPages: 1,
                completedPages: 1
            });

            return pdfPath;

        } finally {
            await browser.close();
        }
    }

    async cleanup() {
        try {
            // 清理临时文件
            const tempFiles = await fs.readdir(this.tempDir);
            for (const file of tempFiles) {
                await fs.unlink(path.join(this.tempDir, file));
            }
            console.log('临时文件清理完成');
        } catch (error) {
            console.warn('清理临时文件时出错:', error.message);
        }
    }

    escapeHtml(text) {
        if (!text) return '';
        return text
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#39;');
    }

    // 根据选项处理内容
    processContentByOptions(content) {
        if (!content || typeof content !== 'string') {
            return '';
        }

        let processedContent = content;
        const cheerio = require('cheerio');
        
        try {
            const $ = cheerio.load(processedContent);
            
            console.log('正在处理内容选项:', {
                includeImages: this.includeImages,
                includeStyles: this.includeStyles
            });
            
            // 处理图片选项
            if (!this.includeImages) {
                console.log('移除图片元素，但保留渐变背景');
                $('img').remove();
                $('picture').remove();
                $('svg').remove();
                // 只移除图片背景，保留渐变和纯色背景
                $('*').each(function() {
                    const $el = $(this);
                    const style = $el.attr('style');
                    if (style && (style.includes('background-image') || style.includes('background:'))) {
                        // 只移除包含URL的图片背景，保留渐变背景
                        const newStyle = style
                            .replace(/background-image\s*:\s*url[^;]*;?/gi, '')
                            .replace(/background\s*:\s*[^;]*url[^;]*;?/gi, '')
                            // 保留渐变背景！
                            // .replace(/background[^;]*linear-gradient[^;]*;?/gi, '') // 删除这行
                            .trim();
                        if (newStyle) {
                            $el.attr('style', newStyle);
                        } else {
                            $el.removeAttr('style');
                        }
                    }
                });
            }
            
            // 处理样式选项
            if (!this.includeStyles) {
                console.log('移除所有样式元素');
                $('style').remove();
                $('link[rel="stylesheet"]').remove();
                // 移除内联样式
                $('*').removeAttr('style');
                $('*').removeAttr('class');
                $('*').removeAttr('id');
            } else {
                console.log('保留所有样式元素，优化PDF渲染兼容性');
                // 保留更多样式，只移除真正会导致PDF渲染问题的样式
                $('*').each(function() {
                    const $el = $(this);
                    const style = $el.attr('style');
                    if (style) {
                        // 只移除真正有问题的样式，保留更多装饰效果
                        let newStyle = style
                            // 修复定位问题（fixed/absolute在PDF中可能不正确）
                            .replace(/position\s*:\s*fixed/gi, 'position: relative')
                            .replace(/position\s*:\s*absolute/gi, 'position: relative')
                            // 移除动画相关（PDF是静态文档）
                            .replace(/animation[^;]*;?/gi, '')
                            .replace(/transition[^;]*;?/gi, '')
                            // 保留transform，但移除可能有问题的动画相关的transform
                            .replace(/transform\s*:[^;]*animation[^;]*;?/gi, '')
                            // 移除互动相关的样式
                            .replace(/cursor\s*:[^;]*;?/gi, '')
                            // 保留其他所有样式：渐变、阴影、边框、颜色等
                            .trim();
                        
                        if (newStyle !== style && newStyle) {
                            $el.attr('style', newStyle);
                        }
                    }
                });
                
                // 为了更好地支持复杂样式，添加PDF友好的CSS
                const pdfOptimizedCSS = `
                    <style>
                        /* PDF优化样式 */
                        * {
                            -webkit-print-color-adjust: exact !important;
                            color-adjust: exact !important;
                            print-color-adjust: exact !important;
                        }
                        /* 确保渐变背景可以渲柕 */
                        .status, .instructions, .test-content {
                            -webkit-print-color-adjust: exact;
                            print-color-adjust: exact;
                        }
                    </style>
                `;
                
                // 在head中添加优化样式
                if ($('head').length > 0) {
                    $('head').append(pdfOptimizedCSS);
                } else {
                    $('body').prepend(pdfOptimizedCSS);
                }
            }
            
            processedContent = $.html();
            
        } catch (error) {
            console.warn('内容选项处理时出错:', error.message);
        }
        
        return processedContent;
    }

    // 最终内容清理方法
    finalContentCleanup(content) {
        if (!content || typeof content !== 'string') {
            return '';
        }

        // 使用正则表达式移除不需要的文本
        let cleanedContent = content;
        
        // 定义所有可能的不需要文本模式
        const unwantedPatterns = [
            // 直接文本匹配
            /No results matching\s*["']?[^"'<>]*["']?/gi,
            /results matching\s*["']?[^"'<>]*["']?/gi,
            /No results found/gi,
            /Search results/gi,
            /Powered by GitBook/gi,
            /Edit on GitHub/gi,
            /Last updated/gi,
            // HTML元素中的文本
            /<[^>]*>\s*No results matching[^<]*<\/[^>]*>/gi,
            /<[^>]*>\s*results matching[^<]*<\/[^>]*>/gi,
            /<[^>]*>\s*No results found[^<]*<\/[^>]*>/gi,
            /<[^>]*>\s*Search results[^<]*<\/[^>]*>/gi,
            // 单行文本
            /^\s*No results matching\s*["']?[^"']*["']?\s*$/gm,
            /^\s*results matching\s*["']?[^"']*["']?\s*$/gm,
            /^\s*No results\s*$/gm,
            // 空元素
            /<p>\s*<\/p>/gi,
            /<div>\s*<\/div>/gi,
            /<span>\s*<\/span>/gi,
            /<h[1-6]>\s*<\/h[1-6]>/gi,
            // 只包含空白的元素
            /<[^>]+>\s*<\/[^>]+>/gi
        ];
        
        // 逐个应用清理模式
        unwantedPatterns.forEach(pattern => {
            cleanedContent = cleanedContent.replace(pattern, '');
        });
        
        // 特殊处理：移除只包含不需要关键词的段落
        const cheerio = require('cheerio');
        try {
            const $ = cheerio.load(cleanedContent);
            
            $('*').each(function() {
                const $element = $(this);
                const text = $element.text().trim();
                
                // 检查是否只包含不需要的关键词
                const unwantedKeywords = [
                    'No results matching',
                    'results matching',
                    'No results found',
                    'Search results',
                    'Powered by GitBook'
                ];
                
                if (unwantedKeywords.some(keyword => 
                    text.toLowerCase().includes(keyword.toLowerCase()) && text.length < 100
                )) {
                    // 检查是否只包含不需要内容，没有其他有用信息
                    if (!$element.find('h1, h2, h3, h4, h5, h6, p, ul, ol, table, img').length || 
                        $element.children().length === 0) {
                        $element.remove();
                    }
                }
            });
            
            cleanedContent = $.html();
        } catch (error) {
            console.warn('内容清理时出错:', error.message);
        }
        
        // 最后一次文本清理
        cleanedContent = cleanedContent
            .replace(/\s*No results matching[^\n]*/gi, '')
            .replace(/\s*results matching[^\n]*/gi, '')
            .replace(/\s*No results found[^\n]*/gi, '')
            .replace(/\n\s*\n\s*\n/g, '\n\n') // 减少多余的空行
            .trim();
        
        return cleanedContent;
    }

    // 生成单页PDF（用于调试）
    async generateSinglePagePDF(pageData, outputPath) {
        // 处理页面内容，应用相同的样式优化
        let processedContent = this.processContentByOptions(pageData.content || '');
        
        const htmlContent = `
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>${this.escapeHtml(pageData.title)}</title>
    <style>
        body { 
            font-family: 'Microsoft YaHei', Arial, sans-serif; 
            margin: 40px; 
            line-height: 1.6;
            -webkit-print-color-adjust: exact !important;
            color-adjust: exact !important;
            print-color-adjust: exact !important;
        }
        h1 { color: #333; }
        .url { color: #666; font-size: 12px; margin-bottom: 20px; }
        /* 支持复杂样式渲染 */
        * {
            -webkit-print-color-adjust: exact !important;
            color-adjust: exact !important;
            print-color-adjust: exact !important;
        }
    </style>
</head>
<body>
    <h1>${this.escapeHtml(pageData.title)}</h1>
    <div class="url">${this.escapeHtml(pageData.url)}</div>
    <div>${processedContent}</div>
</body>
</html>`;

        const htmlPath = path.join(this.tempDir, 'single.html');
        await fs.writeFile(htmlPath, htmlContent, 'utf8');

        const browser = await puppeteer.launch({ headless: 'new' });
        try {
            const page = await browser.newPage();
            
            // 模拟浏览器打印时勾选"背景图片"选项的效果
            await page.emulateMediaType('print');
            
            // 强制启用背景图片渲染
            await page.evaluateOnNewDocument(() => {
                const style = document.createElement('style');
                style.textContent = `
                    * {
                        -webkit-print-color-adjust: exact !important;
                        color-adjust: exact !important;
                        print-color-adjust: exact !important;
                    }
                `;
                document.head.appendChild(style);
            });
            
            await page.goto(`file://${htmlPath}`, { waitUntil: 'networkidle0' });
            await page.pdf({
                path: outputPath,
                format: 'A4',
                printBackground: true,
                omitBackground: false,
                scale: 1,
                tagged: false,
                outline: false
            });
        } finally {
            await browser.close();
        }
    }
}

module.exports = PDFGenerator;